extends Node3D

const WORLD_SIZE := 90.0
const PLAYER_SPEED := 7.0
const BOT_COUNT := 9

var player: CharacterBody3D
var camera: Camera3D
var yaw := 0.0
var pitch := -0.22
var health := 100.0
var ammo := 30
var reserve_ammo := 120
var kills := 0
var match_time := 0.0
var zone_radius := 42.0
var game_over := false
var bots: Array[CharacterBody3D] = []
var fire_cooldown := 0.0
var reload_time := 0.0

var move_touch := Vector2.ZERO
var look_touch := Vector2.ZERO
var active_move_finger := -1
var active_look_finger := -1
var fire_held := false
var hud: Label
var status_label: Label
var joystick_base: ColorRect
var joystick_knob: ColorRect
var fire_button: Button
var reload_button: Button
var touch_look_origin := Vector2.ZERO

func _ready() -> void:
	_setup_input()
	_create_world()
	_create_player()
	_create_bots()
	_create_hud()
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _setup_input() -> void:
	var actions = {
		"move_forward": [KEY_W, KEY_UP],
		"move_back": [KEY_S, KEY_DOWN],
		"move_left": [KEY_A, KEY_LEFT],
		"move_right": [KEY_D, KEY_RIGHT],
		"fire": [KEY_SPACE],
		"reload": [KEY_R]
	}
	for action in actions:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		for keycode in actions[action]:
			var ev := InputEventKey.new()
			ev.physical_keycode = keycode
			InputMap.action_add_event(action, ev)

func _create_world() -> void:
	var env := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_SKY
	environment.sky = Sky.new()
	environment.sky.sky_material = ProceduralSkyMaterial.new()
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color(0.72, 0.78, 0.86)
	environment.ambient_light_energy = 0.8
	env.environment = environment
	add_child(env)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55, -25, 0)
	sun.light_energy = 1.2
	add_child(sun)

	_make_box("Ground", Vector3(0, -0.6, 0), Vector3(WORLD_SIZE, 1.0, WORLD_SIZE), Color(0.22, 0.48, 0.24))
	# Estradas e construções simples para formar uma pequena ilha jogável.
	_make_box("Road", Vector3(0, -0.05, 0), Vector3(8, 0.12, 78), Color(0.24, 0.24, 0.23))
	_make_box("CrossRoad", Vector3(0, -0.04, 0), Vector3(78, 0.13, 7), Color(0.24, 0.24, 0.23))
	for i in range(18):
		var x := randf_range(-38, 38)
		var z := randf_range(-38, 38)
		if abs(x) < 8 or abs(z) < 7:
			continue
		_make_tree(Vector3(x, 0, z))
	for i in range(8):
		var x := randf_range(-32, 32)
		var z := randf_range(-32, 32)
		_make_building(Vector3(x, 0, z), randf_range(4.0, 7.0))

	# Limite visual da arena.
	for i in range(32):
		var angle := TAU * float(i) / 32.0
		var p := Vector3(cos(angle) * 44.0, 0.1, sin(angle) * 44.0)
		var pillar := _make_box("Boundary", p, Vector3(0.45, 1.4, 0.45), Color(0.15, 0.8, 1.0), false)
		pillar.transparency = 0.15

func _make_box(n: String, pos: Vector3, size: Vector3, color: Color, collision := true) -> MeshInstance3D:
	var body: Node3D
	if collision:
		var static_body := StaticBody3D.new()
		static_body.position = pos
		add_child(static_body)
		body = static_body
		var shape := CollisionShape3D.new()
		var box_shape := BoxShape3D.new()
		box_shape.size = size
		shape.shape = box_shape
		static_body.add_child(shape)
	else:
		var node := Node3D.new()
		node.position = pos
		add_child(node)
		body = node
	var mesh := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = size
	mesh.mesh = box
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mesh.material_override = mat
	body.add_child(mesh)
	mesh.position.y = 0
	mesh.name = n
	return mesh

func _make_tree(pos: Vector3) -> void:
	var trunk := _make_box("TreeTrunk", pos + Vector3(0, 1.0, 0), Vector3(0.65, 2.0, 0.65), Color(0.28, 0.16, 0.08))
	var crown := MeshInstance3D.new()
	var sphere := SphereMesh.new()
	sphere.radius = 1.65
	sphere.height = 3.3
	crown.mesh = sphere
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.08, randf_range(0.28, 0.42), 0.12)
	crown.material_override = mat
	crown.position = pos + Vector3(0, 3.0, 0)
	add_child(crown)

func _make_building(pos: Vector3, width: float) -> void:
	var h := randf_range(3.0, 5.0)
	_make_box("Building", pos + Vector3(0, h / 2.0, 0), Vector3(width, h, width), Color(0.55, 0.52, 0.44))
	_make_box("Roof", pos + Vector3(0, h + 0.12, 0), Vector3(width + 0.3, 0.25, width + 0.3), Color(0.28, 0.25, 0.22))

func _make_character(color: Color, pos: Vector3, is_player := false) -> CharacterBody3D:
	var actor := CharacterBody3D.new()
	actor.position = pos
	actor.floor_snap_length = 0.3
	add_child(actor)
	var capsule := CapsuleMesh.new()
	capsule.radius = 0.48
	capsule.height = 1.8
	var mesh := MeshInstance3D.new()
	mesh.mesh = capsule
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mesh.material_override = mat
	mesh.position.y = 0.9
	actor.add_child(mesh)
	var collision := CollisionShape3D.new()
	var shape := CapsuleShape3D.new()
	shape.radius = 0.42
	shape.height = 1.8
	collision.shape = shape
	collision.position.y = 0.9
	actor.add_child(collision)
	if is_player:
		var pivot := Node3D.new()
		pivot.name = "CameraPivot"
		pivot.position = Vector3(0, 1.45, 0)
		actor.add_child(pivot)
		camera = Camera3D.new()
		camera.position = Vector3(0, 2.3, 5.8)
		camera.rotation_degrees.x = -12
		camera.current = true
		pivot.add_child(camera)
	return actor

func _create_player() -> void:
	player = _make_character(Color(0.12, 0.42, 0.95), Vector3(0, 0, 18), true)

func _create_bots() -> void:
	for i in range(BOT_COUNT):
		var p := Vector3(randf_range(-30, 30), 0, randf_range(-30, 30))
		if p.distance_to(player.position) < 12:
			p.x += 18
		var bot := _make_character(Color(0.82, 0.18, 0.14), p)
		bot.set_meta("hp", 100.0)
		bot.set_meta("shot_timer", randf_range(0.6, 2.0))
		bots.append(bot)

func _create_hud() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var panel := PanelContainer.new()
	panel.position = Vector2(18, 16)
	panel.custom_minimum_size = Vector2(270, 110)
	layer.add_child(panel)
	var vbox := VBoxContainer.new()
	panel.add_child(vbox)
	hud = Label.new()
	hud.add_theme_font_size_override("font_size", 20)
	vbox.add_child(hud)
	status_label = Label.new()
	status_label.add_theme_font_size_override("font_size", 16)
	vbox.add_child(status_label)

	var hint := Label.new()
	hint.text = "PC: WASD + mouse | Espaço: atirar | R: recarregar"
	hint.position = Vector2(18, 132)
	hint.add_theme_font_size_override("font_size", 14)
	layer.add_child(hint)

	# Controles de toque: joystick à esquerda, arraste à direita para mirar.
	joystick_base = ColorRect.new()
	joystick_base.color = Color(0.1, 0.1, 0.1, 0.35)
	joystick_base.size = Vector2(150, 150)
	joystick_base.position = Vector2(38, 520)
	joystick_base.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(joystick_base)
	joystick_knob = ColorRect.new()
	joystick_knob.color = Color(0.85, 0.9, 1.0, 0.65)
	joystick_knob.size = Vector2(58, 58)
	joystick_knob.position = Vector2(46, 46)
	joystick_base.add_child(joystick_knob)

	fire_button = Button.new()
	fire_button.text = "ATIRAR"
	fire_button.position = Vector2(1080, 540)
	fire_button.size = Vector2(150, 100)
	fire_button.add_theme_font_size_override("font_size", 22)
	layer.add_child(fire_button)
	fire_button.button_down.connect(func(): fire_held = true)
	fire_button.button_up.connect(func(): fire_held = false)

	reload_button = Button.new()
	reload_button.text = "RECARREGAR"
	reload_button.position = Vector2(1070, 445)
	reload_button.size = Vector2(160, 65)
	layer.add_child(reload_button)
	reload_button.pressed.connect(_reload)

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		yaw -= event.relative.x * 0.003
		pitch = clamp(pitch - event.relative.y * 0.0025, -0.65, 0.18)
	elif event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	elif event is InputEventScreenTouch:
		if event.pressed:
			if event.position.x < get_viewport().get_visible_rect().size.x * 0.48 and active_move_finger == -1:
				active_move_finger = event.index
				_update_joystick(event.position)
			elif active_look_finger == -1:
				active_look_finger = event.index
				touch_look_origin = event.position
		else:
			if event.index == active_move_finger:
				active_move_finger = -1
				move_touch = Vector2.ZERO
				joystick_knob.position = Vector2(46, 46)
			if event.index == active_look_finger:
				active_look_finger = -1
	elif event is InputEventScreenDrag:
		if event.index == active_move_finger:
			_update_joystick(event.position)
		elif event.index == active_look_finger:
			yaw -= event.relative.x * 0.006
			pitch = clamp(pitch - event.relative.y * 0.004, -0.65, 0.18)

func _update_joystick(screen_pos: Vector2) -> void:
	var center := joystick_base.global_position + joystick_base.size / 2.0
	var delta := screen_pos - center
	move_touch = (delta / 58.0).limit_length(1.0)
	joystick_knob.position = Vector2(46, 46) + move_touch * 42.0

func _physics_process(delta: float) -> void:
	if game_over:
		return
	match_time += delta
	fire_cooldown = maxf(0.0, fire_cooldown - delta)
	if reload_time > 0:
		reload_time -= delta
		if reload_time <= 0:
			var needed := 30 - ammo
			var loaded := mini(needed, reserve_ammo)
			ammo += loaded
			reserve_ammo -= loaded

	_update_player(delta)
	_update_bots(delta)
	_update_zone(delta)
	if fire_held or Input.is_action_pressed("fire"):
		_shoot()
	_update_hud()
	if bots.is_empty():
		_end_game(true)
	if health <= 0:
		_end_game(false)

func _update_player(delta: float) -> void:
	var input_dir := Vector2.ZERO
	input_dir.y -= float(Input.is_action_pressed("move_forward"))
	input_dir.y += float(Input.is_action_pressed("move_back"))
	input_dir.x -= float(Input.is_action_pressed("move_left"))
	input_dir.x += float(Input.is_action_pressed("move_right"))
	if move_touch.length() > 0.08:
		input_dir = Vector2(move_touch.x, move_touch.y)
	input_dir = input_dir.limit_length(1.0)
	var forward := Vector3(sin(yaw), 0, cos(yaw))
	var right := Vector3(cos(yaw), 0, -sin(yaw))
	var direction := (right * input_dir.x + forward * input_dir.y).normalized()
	player.velocity.x = direction.x * PLAYER_SPEED
	player.velocity.z = direction.z * PLAYER_SPEED
	if not player.is_on_floor():
		player.velocity.y -= 22.0 * delta
	else:
		player.velocity.y = -0.5
	player.move_and_slide()
	player.rotation.y = yaw
	var pivot: Node3D = player.get_node("CameraPivot")
	pivot.rotation.y = 0
	pivot.rotation.x = pitch

func _update_bots(delta: float) -> void:
	for bot in bots.duplicate():
		if not is_instance_valid(bot):
			bots.erase(bot)
			continue
		var to_player := player.global_position - bot.global_position
		var distance := to_player.length()
		var dir := to_player.normalized()
		if distance > 8.0:
			bot.velocity.x = dir.x * 3.2
			bot.velocity.z = dir.z * 3.2
			bot.rotation.y = atan2(dir.x, dir.z)
		else:
			bot.velocity.x = 0
			bot.velocity.z = 0
			var timer := float(bot.get_meta("shot_timer")) - delta
			if timer <= 0:
				if randf() < 0.55:
					health -= randf_range(4.0, 9.0)
				timer = randf_range(1.0, 2.0)
			bot.set_meta("shot_timer", timer)
		if not bot.is_on_floor():
			bot.velocity.y -= 22.0 * delta
		else:
			bot.velocity.y = -0.5
		bot.move_and_slide()
		if bot.global_position.distance_to(Vector3.ZERO) > 65:
			bot.global_position = Vector3(randf_range(-20, 20), 0, randf_range(-20, 20))

func _shoot() -> void:
	if fire_cooldown > 0 or reload_time > 0:
		return
	if ammo <= 0:
		_reload()
		return
	ammo -= 1
	fire_cooldown = 0.16
	var origin := camera.global_position
	var direction := -camera.global_transform.basis.z
	var query := PhysicsRayQueryParameters3D.create(origin, origin + direction * 65.0)
	query.exclude = [player]
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	if hit and hit.collider in bots:
		var bot: CharacterBody3D = hit.collider
		bot.set_meta("hp", float(bot.get_meta("hp")) - 50.0)
		if float(bot.get_meta("hp")) <= 0:
			bots.erase(bot)
			bot.queue_free()
			kills += 1

func _reload() -> void:
	if reload_time <= 0 and ammo < 30 and reserve_ammo > 0:
		reload_time = 1.35

func _update_zone(delta: float) -> void:
	zone_radius = maxf(12.0, 42.0 - match_time * 0.12)
	var dist := Vector2(player.global_position.x, player.global_position.z).length()
	if dist > zone_radius:
		health -= 7.0 * delta
	for bot in bots:
		var bd := Vector2(bot.global_position.x, bot.global_position.z).length()
		if bd > zone_radius:
			bot.set_meta("hp", float(bot.get_meta("hp")) - delta * 4.0)
			if float(bot.get_meta("hp")) <= 0:
				bots.erase(bot)
				bot.queue_free()

func _update_hud() -> void:
	hud.text = "VIDA: %d   |   MUNIÇÃO: %d/%d\nELIMINAÇÕES: %d   |   INIMIGOS: %d" % [int(maxf(health, 0)), ammo, reserve_ammo, kills, bots.size()]
	var reload_text := " | RECARREGANDO" if reload_time > 0 else ""
	status_label.text = "ZONA SEGURA: %.0f m%s" % [zone_radius, reload_text]
	if health < 35:
		status_label.add_theme_color_override("font_color", Color(1, 0.25, 0.2))
	else:
		status_label.add_theme_color_override("font_color", Color(0.1, 0.9, 0.3))

func _end_game(victory: bool) -> void:
	game_over = true
	var message := "VITÓRIA! VOCÊ É O ÚLTIMO SOBREVIVENTE!" if victory else "FIM DE JOGO"
	status_label.text = message + "\nEliminações: " + str(kills)
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
