# Ilha Battle 3D (Android)

Protótipo jogável de battle royale em terceira pessoa, feito para **Godot 4.3+**.

## O que já funciona
- Personagem 3D em terceira pessoa.
- Câmera atrás do jogador, com controle por arraste no celular.
- Joystick virtual para movimentação.
- Botão de tiro e botão de recarga.
- 9 inimigos controlados por IA simples.
- Vida, munição, eliminações e contagem de inimigos.
- Zona segura que diminui e causa dano fora dela.
- Cenário criado proceduralmente com árvores, prédios e estradas.
- Controles de teclado e mouse para testar no computador.

## Como executar
1. Instale o **Godot 4.3 ou superior**.
2. Extraia a pasta `ilha_battle_android`.
3. Abra o Godot, escolha **Importar** e selecione `project.godot`.
4. Pressione **F6** ou **F5** para jogar.

## Como gerar APK para Android
1. No Godot, instale os templates de exportação em **Editor > Manage Export Templates**.
2. Configure o Android SDK/JDK em **Editor > Editor Settings > Export > Android**.
3. Abra **Project > Export**, adicione um preset **Android** e configure o identificador do pacote.
4. Exporte como APK para teste ou AAB para publicação.

## Controles
- **Android:** joystick esquerdo para andar; arraste a metade direita da tela para olhar; ATIRAR e RECARREGAR.
- **PC:** WASD/setas para andar; mouse para olhar; Espaço para atirar; R para recarregar.

## Observações
Este é um protótipo inicial offline, não um clone completo de Free Fire. Os personagens, cenário e efeitos usam formas 3D simples para manter o projeto leve e fácil de ampliar. Ainda não há multiplayer online, paraquedas, inventário, veículos, animações avançadas ou matchmaking.
